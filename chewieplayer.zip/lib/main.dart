import 'package:chewplayer/app/app.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(
    const ChewieDemo(),
  );
}
